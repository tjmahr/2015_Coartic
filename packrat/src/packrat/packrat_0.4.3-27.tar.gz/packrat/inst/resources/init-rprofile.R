#### -- Packrat Autoloader (version 0.4.3-27) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
